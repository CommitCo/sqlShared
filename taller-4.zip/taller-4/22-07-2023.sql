--------- UTILIZAMOS LA BASE DE DATOS DE LA ACTIVIDAD ANTERIOR ---------

------------------- EJERCICIO 1 -------------------

-- Asignación de la base de datos que utilizaremos
USE FACTURACION;
-- Obtener todos los clientes que tangan por lo menos una factura.
SELECT * FROM clientes INNER JOIN factura ON clientes.id_clientes = factura .id_clientes;

------------------- EJERCICIO 2 -------------------

-- Obtener todos los clientes con sus facturas, mostrando también los clientes que no tienen factura. (teoría de conjuntos, lado izquierdo)
-- a) Obtener todos los clientes con sus facturas:
SELECT * FROM clientes LEFT JOIN factura ON clientes.id_clientes = factura.id_clientes;
-- b) Mostrando también los clientes que no tienen factura.
SELECT * FROM clientes LEFT JOIN factura ON clientes.id_clientes = factura.id_clientes WHERE factura.id_clientes IS NULL;

------------------- EJERCICIO 3 -------------------

-- Obtener todas las facturas de clientes, mostrando también las facturas que no tienen cliente asociado. (teoría de conjuntos, lado derecho)
-- a) Obtener todas las facturas de clientes.
SELECT * FROM clientes RIGHT JOIN factura ON clientes.id_clientes = factura.id_clientes;
-- b) Obtener las facturas que no tienen cliente asociado.
SELECT * FROM clientes RIGHT JOIN factura ON clientes.id_clientes = factura.id_clientes WHERE factura.id_clientes IS NULL;

-- La sintaxis de OUTER JOIN o FULL OUTER JOIN no existen en MySQL, pero se puede conseguir el mismo resultado de diferentes formas, esta es una: 
SELECT * FROM clientes LEFT JOIN factura ON clientes.id_clientes = factura.id_clientes
UNION
SELECT * FROM clientes RIGHT JOIN factura ON clientes.id_clientes = factura.id_clientes;


------------------- Taller practico -------------------
CREATE DATABASE oasis_spa;

USE oasis_spa;

CREATE TABLE cliente (
    clienId VARCHAR (30) UNIQUE PRIMARY KEY COMMENT 'Id cliente',
    clieNom VARCHAR (25) NOT NULL COMMENT 'Nombre',
    clieApe VARCHAR (25) NOT NULL COMMENT 'Apellido',
    cliDire  VARCHAR (20) NOT NULL COMMENT 'Direccion',
    clietel VARCHAR (20) NOT NULL COMMENT 'telefono',
    cliEmai VARCHAR (50) UNIQUE NOT NULL COMMENT 'correo',
    climuni VARCHAR(20) COMMENT 'municipio',
    clidepa VARCHAR(20) COMMENT 'departamento',
    clipais VARCHAR (20) COMMENT 'pais',
    estado
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE producto (
    producCod VARCHAR (30) UNIQUE PRIMARY KEY COMMENT 'Codigo Producto',
    producCant INT(10) NOT NULL COMMENT 'Cantidad',
    producNom VARCHAR (25) NOT NULL COMMENT 'Nombre producto',
    producpre INT (25) NOT NULL COMMENT 'Precio Producto',
    stock INT (25) NOT NULL COMMENT 'Stock producto',
    estado
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE servicio (
    servicioId INT PRIMARY KEY COMMENT 'Id servicio',
    serviNom VARCHAR(100) NOT NULL COMMENT 'Nombre',
    serviDesc TEXT NOT NULL COMMENT 'Descripcion',
    serviPrec DECIMAL(10, 2) COMMENT 'Precio'
    estado 
);

CREATE TABLE agenda (
    agendaId INT PRIMARY KEY COMMENT 'Id Agenda'
    clienId
    servicioId
    agenFecha
    agenHora
    agenObser TEXT
    estado
);